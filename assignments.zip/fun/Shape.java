package com.lumen.fun;

public interface Shape {
	double calcArea(double x,double y);

}
