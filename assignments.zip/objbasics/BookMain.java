package com.lumen.objbasics;

public class BookMain {

	public static void main(String[] args) {
		Book book1=new Book("2 states","Chetan Bhagat",176.0);
		Book book2=new Book("Shiva Trilogy","Amish Tripathi",700.0);
		book1.printdetails();
		book1.CheckBookType();
		System.out.println();
		book2.printdetails();
		book2.CheckBookType();	
		

	}

}
