package com.lumen.basic;

import java.util.Arrays;

public class SortAscending {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] array= {10,20,30,45,5,7,23,27,35};
		Arrays.sort(array);
		for(int number:array)
			System.out.print(number+" ");

	}

}
