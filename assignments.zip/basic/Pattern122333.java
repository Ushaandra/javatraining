package com.lumen.basic;

public class Pattern122333 {

	public static void main(String[] args) {
		int range=5;
		for(int i=1;i<=range;i++) {
			for(int j=0;j<i;j++) {
				System.out.print(i);
			}
			System.out.println();
		}
	}

}
