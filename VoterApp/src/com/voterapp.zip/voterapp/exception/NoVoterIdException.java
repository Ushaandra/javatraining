package com.voterapp.exception;

public class NoVoterIdException extends Exception{

	public NoVoterIdException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NoVoterIdException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
