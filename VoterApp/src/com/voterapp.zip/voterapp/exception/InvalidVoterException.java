package com.voterapp.exception;

public class InvalidVoterException extends Exception {

	public InvalidVoterException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidVoterException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
