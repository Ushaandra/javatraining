package com.voterapp.exception;

public class UnderAgeException extends Exception{

	public UnderAgeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UnderAgeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
