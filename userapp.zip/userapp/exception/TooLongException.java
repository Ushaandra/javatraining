package com.userapp.exception;

public class TooLongException extends Exception {

	public TooLongException() {
		super();
	}

	public TooLongException(String message) {
		super(message);
	}
	
}
