package com.userapp.exception;

public class NameExistsException extends Exception {

	public NameExistsException() {
		super();
	}

	public NameExistsException(String message) {
		super(message);
	}
	
}
